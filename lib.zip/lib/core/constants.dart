const alarmDurationSeconds = 60;

const appTheme = {
  'primary': 0xFF1E88E5,
  'danger': 0xFFD32F2F,
};
