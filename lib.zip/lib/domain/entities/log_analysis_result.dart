class LogAnalysisResult {
  final String summary;

  LogAnalysisResult({required this.summary});
}
